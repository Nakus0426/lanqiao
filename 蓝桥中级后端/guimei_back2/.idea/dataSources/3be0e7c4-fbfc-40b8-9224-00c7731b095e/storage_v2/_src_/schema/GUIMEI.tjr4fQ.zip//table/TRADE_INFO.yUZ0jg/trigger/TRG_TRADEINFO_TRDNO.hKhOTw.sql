create trigger TRG_TRADEINFO_TRDNO
  before insert
  on TRADE_INFO
  for each row
  when (NEW.trd_no is null)
declare

begin
  if inserting then
    :NEW.trd_no := getOrderNo;

  end if;

end trg_tradeinfo_trdno;
/

