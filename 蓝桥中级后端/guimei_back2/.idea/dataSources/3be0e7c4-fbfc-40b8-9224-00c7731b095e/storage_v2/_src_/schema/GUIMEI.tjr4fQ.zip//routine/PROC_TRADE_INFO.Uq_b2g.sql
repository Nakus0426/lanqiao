create procedure proc_trade_info(t_buyer in trade_info.buyer%type,
                                            t_total_money in trade_info.total_money%type,
                                            t_trd_loc in trade_info.trd_loc%type,
                                            t_receiver in trade_info.receiver%type,
                                            t_phone in trade_info.phone%type,
                                            t_prod_no in sale_prod.prod_no%type,
                                            t_tran_numb in tran_statistics.tran_numb%type)
  is
  v_time tran_statistics.tran_time%type;            -- 交易时间
  v_ctgr_name tran_statistics.ctgr_name%type;       -- 交易物品的小类
  v_big_ctgr tran_statistics.big_ctgr%type;         -- 交易物品的大类
  v_trd_no trade_detail.trd_no%type;                -- 交易编号
  v_saler trade_detail.saler%type;                  -- 卖家
  -- 自定义异常，用于事务的提交或者回滚
  ex_affail exception;
begin
  -- 通过函数获取交易编号，yyyyMMddhhmmss+oracle4位随机数
  v_trd_no := getOrderNo;
  -- 执行插入交易信息表
  insert into trade_info(trd_no, buyer, total_money, trd_loc, receiver, phone, trd_status) values(v_trd_no, t_buyer, t_total_money, t_trd_loc, t_receiver, t_phone, 1);
  --commit

  --select t.trd_time into v_time from (select t.trd_time from trade_info t order by t.trd_time desc)t where rownum = 1;
  -- 通过商品的 prod_no编号 （唯一）来获取你购买的商品 的大类和小类名称
  select c.ctgr_name into v_ctgr_name from category c, (select p.ctgr_id from  product p where p.prod_no = t_prod_no) p where c.ctgr_id = p.ctgr_id;
  select c.big_ctgr into v_big_ctgr from category c, (select p.ctgr_id from  product p where p.prod_no = t_prod_no) p where c.ctgr_id = p.ctgr_id;
  -- 执行插入 交易量统计表
  insert into tran_statistics(tran_numb, ctgr_name, big_ctgr) values(t_tran_numb, v_ctgr_name, v_big_ctgr);
  --commit;


  --select t.trd_no into v_trd_no from (select t.trd_no from trade_info t order by t.trd_time desc)t where rownum = 1;
  select p.ven_id into v_saler  from product p where p.prod_no = t_prod_no;
  -- 执行插入交易明细表
  insert into trade_detail values(v_trd_no, t_prod_no, v_saler, t_tran_numb, t_total_money);

  -- 事务全部成功，可以提交
  commit;

  -- 异常处理，只要有一条插入语句失败就回滚
  exception
  when others then
    rollback;
    RAISE_APPLICATION_ERROR(-20000, '调用存储过程插入订单表失败，违反事务的原子性！！');


end proc_trade_info;
/

