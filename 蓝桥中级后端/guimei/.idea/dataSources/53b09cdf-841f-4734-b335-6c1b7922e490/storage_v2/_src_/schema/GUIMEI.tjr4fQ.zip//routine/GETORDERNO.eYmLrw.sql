create function getOrderNo
	return varchar2
is
   no varchar2(18);
begin
 select to_char(sysdate,'YYYYMMDDHH24MISS')||substr(to_char(dbms_random.value,'0.999999999999999'),15) into no from dual;
  return no;
end;
/

