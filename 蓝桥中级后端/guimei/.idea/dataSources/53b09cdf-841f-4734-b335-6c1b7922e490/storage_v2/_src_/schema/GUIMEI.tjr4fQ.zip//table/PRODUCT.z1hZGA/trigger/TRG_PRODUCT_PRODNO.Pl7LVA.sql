create trigger TRG_PRODUCT_PRODNO
  before insert
  on PRODUCT
  for each row
  when (NEW.prod_no is null)
declare

begin
  if inserting then
    :NEW.prod_no := sys_guid();
  end if;

end trg_product_prodno;
/

